%% STEP 7B: Compare prediction vs ground-truth on random validation images
clear; clc; close all;

root = "D:\Onedrive\OneDrive - IIT Delhi\IIT DElhi\Course\CAV COurse\Matlab\yoloLearn\archive\Cars Detection";
load(fullfile(root,"yolo_detector_trained.mat"), "detector");
load(fullfile(root,"yolo_tables_carsDetection.mat"), "valTbl");

boxCols = valTbl.Properties.VariableNames;
boxCols = boxCols(~strcmp(boxCols,"imageFilename"));

rng(1);
nShow = min(10, height(valTbl));
idx = randperm(height(valTbl), nShow);

threshold = 0.30;

for n = 1:nShow
    i = idx(n);
    imgPath = string(valTbl.imageFilename(i));
    I = imread(imgPath);

    % Ground truth
    gtBoxes = [];
    gtLabels = strings(0);
    for k = 1:numel(boxCols)
        B = valTbl.(boxCols{k}){i};
        if ~isempty(B)
            gtBoxes = [gtBoxes; B]; %#ok<AGROW>
            gtLabels = [gtLabels; repmat(string(boxCols{k}), size(B,1), 1)]; %#ok<AGROW>
        end
    end

    Igt = insertObjectAnnotation(I, "rectangle", gtBoxes, gtLabels);

    % Predictions
    [bboxes, scores, labels] = detect(detector, I, "Threshold", threshold);
    if ~isempty(bboxes)
        ann = string(labels) + " : " + string(round(scores,2));
        Ipred = insertObjectAnnotation(I, "rectangle", bboxes, ann);
    else
        Ipred = I;
    end

    figure(1);
    clf;
    tiledlayout(1,2,"Padding","compact","TileSpacing","compact");
    nexttile; imshow(Igt);   title("Ground Truth");
    nexttile; imshow(Ipred); title(sprintf("Prediction (Thr=%.2f)", threshold));

    sgtitle(sprintf("Image %d/%d | %s", n, nShow, imgPath), "Interpreter","none");

    disp("Press Enter for next image...");
    pause;
end