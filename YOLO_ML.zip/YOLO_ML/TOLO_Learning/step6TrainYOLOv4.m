%% STEP 6 (CPU-friendly): Train YOLOv4 detector overnight
% Uses MaxEpochs=5 and MiniBatchSize=2
% Saves trained detector at the end.

%% Train again (safe settings to avoid NaN/Inf)
clear; clc;

root = "D:\Onedrive\OneDrive - IIT Delhi\IIT DElhi\Course\CAV COurse\Matlab\yoloLearn\archive\Cars Detection";
load(fullfile(root,"yolo_datastores_carsDetection_CLEAN.mat"), "dsTrain", "dsVal");
load(fullfile(root,"yolo_detector_init.mat"), "detector", "classNames", "inputSize"); %#ok<NASGU>

options = trainingOptions("sgdm", ...
    InitialLearnRate=1e-4, ...          % reduced
    MaxEpochs=5, ...
    MiniBatchSize=2, ...
    Shuffle="every-epoch", ...
    VerboseFrequency=20, ...
    ValidationData=dsVal, ...
    ValidationFrequency=100, ...
    GradientThreshold=1, ...            % clip gradients
    Plots="training-progress", ...
    ExecutionEnvironment="cpu");

[detector, info] = trainYOLOv4ObjectDetector(dsTrain, detector, options);

save(fullfile(root,"yolo_detector_trained.mat"), "detector", "info", "classNames", "inputSize");
disp("Training complete. Saved: yolo_detector_trained.mat");
