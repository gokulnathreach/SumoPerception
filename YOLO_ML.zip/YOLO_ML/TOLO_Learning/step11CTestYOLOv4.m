%% STEP 11C: TEST split - GT vs Prediction for TWO thresholds (side-by-side)
clear; clc; close all;

root = "D:\Onedrive\OneDrive - IIT Delhi\IIT DElhi\Course\CAV COurse\Matlab\yoloLearn\archive\Cars Detection";

% Load trained detector (epoch50)
load(fullfile(root,"yolo_detector_trained_epoch50.mat"), "detector50");
detector = detector50;

% Load class names
load(fullfile(root,"yolo_tables_carsDetection.mat"), "classNames");

% Test folders
testImgDir = fullfile(root, "test", "images");
testLabDir = fullfile(root, "test", "labels");

imdsTest = imageDatastore(testImgDir);

% Two thresholds to compare
thr1 = 0.10;
thr2 = 0.05;

% Display settings
topK = 8;
nShow = min(15, numel(imdsTest.Files));

rng(1);
idx = randperm(numel(imdsTest.Files), nShow);

for n = 1:numel(idx)
    imgPath = string(imdsTest.Files{idx(n)});
    I = imread(imgPath);

    % ---------- GT from YOLO txt ----------
    [~, base, ~] = fileparts(imgPath);
    labPath = fullfile(testLabDir, base + ".txt");

    gtBoxes = [];
    gtLabels = strings(0);

    if isfile(labPath)
        info = imfinfo(imgPath);
        W = info.Width; H = info.Height;

        lines = readlines(labPath);
        lines = strtrim(lines);
        lines(lines=="") = [];

        for j = 1:numel(lines)
            parts = split(lines(j));
            cls = str2double(parts(1));
            xc  = str2double(parts(2));
            yc  = str2double(parts(3));
            bw  = str2double(parts(4));
            bh  = str2double(parts(5));

            boxW = bw * W;
            boxH = bh * H;
            x = (xc * W) - boxW/2;
            y = (yc * H) - boxH/2;

            gtBoxes  = [gtBoxes; [x y boxW boxH]]; %#ok<AGROW>
            gtLabels = [gtLabels; string(classNames(cls+1))]; %#ok<AGROW>
        end
    end

    Igt = I;
    if ~isempty(gtBoxes)
        Igt = insertObjectAnnotation(Igt, "rectangle", gtBoxes, gtLabels);
    end

    % ---------- Predictions @ thr1 ----------
    Ipred1 = makePredImage(detector, I, thr1, topK);

    % ---------- Predictions @ thr2 ----------
    Ipred2 = makePredImage(detector, I, thr2, topK);

    % ---------- Display 3 panels ----------
    figure(1); clf;
    tiledlayout(1,3,"Padding","compact","TileSpacing","compact");

    nexttile; imshow(Igt);    title("TEST Ground Truth");
    nexttile; imshow(Ipred1); title(sprintf("Pred Thr=%.2f (TopK=%d)", thr1, topK));
    nexttile; imshow(Ipred2); title(sprintf("Pred Thr=%.2f (TopK=%d)", thr2, topK));

    sgtitle(sprintf("Image %d/%d | %s", n, numel(idx), imgPath), "Interpreter","none");

    disp("Press Enter for next image...");
    pause;
end

%% ---------- Local helper function ----------
function Iout = makePredImage(detector, I, thr, topK)
    [bboxes, scores, labels] = detect(detector, I, "Threshold", thr);

    if isempty(scores)
        Iout = I;
        return;
    end

    % Keep topK by score
    [scores, order] = sort(scores, "descend");
    order = order(1:min(topK, numel(order)));
    bboxes = bboxes(order,:);
    scores = scores(1:numel(order));
    labels = labels(order);

    ann = string(labels) + " : " + string(round(scores,2));
    Iout = insertObjectAnnotation(I, "rectangle", bboxes, ann);
end