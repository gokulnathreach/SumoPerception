%% Rebuild dsTrain/dsVal from cleaned tables
clear; clc;

root = "D:\Onedrive\OneDrive - IIT Delhi\IIT DElhi\Course\CAV COurse\Matlab\yoloLearn\archive\Cars Detection";
load(fullfile(root,"yolo_tables_carsDetection_CLEAN.mat"), "trainTbl2", "valTbl2", "classNames");

boxCols = trainTbl2.Properties.VariableNames;
boxCols = boxCols(~strcmp(boxCols,"imageFilename"));

imdsTrain = imageDatastore(trainTbl2.imageFilename);
imdsVal   = imageDatastore(valTbl2.imageFilename);

bldsTrain = boxLabelDatastore(trainTbl2(:, boxCols));
bldsVal   = boxLabelDatastore(valTbl2(:, boxCols));

dsTrain = combine(imdsTrain, bldsTrain);
dsVal   = combine(imdsVal, bldsVal);

save(fullfile(root,"yolo_datastores_carsDetection_CLEAN.mat"), "dsTrain", "dsVal", "classNames", "boxCols", "-v7.3");
disp("Saved: yolo_datastores_carsDetection_CLEAN.mat");
