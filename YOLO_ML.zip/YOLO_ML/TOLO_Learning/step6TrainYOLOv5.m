%% STEP 9: Continue training from epoch-5 detector to improve confidence
clear; clc;

root = "D:\Onedrive\OneDrive - IIT Delhi\IIT DElhi\Course\CAV COurse\Matlab\yoloLearn\archive\Cars Detection";

% Load datastores (use CLEAN if you trained CLEAN; otherwise use normal)
% If you used CLEAN datastores in training, load the CLEAN file here.
if isfile(fullfile(root,"yolo_datastores_carsDetection_CLEAN.mat"))
    load(fullfile(root,"yolo_datastores_carsDetection_CLEAN.mat"), "dsTrain", "dsVal");
else
    load(fullfile(root,"yolo_datastores_carsDetection.mat"), "dsTrain", "dsVal");
end

% Load the already-trained detector (epoch 5)
load(fullfile(root,"yolo_detector_trained.mat"), "detector");

% Save a copy as "epoch5" so you never lose it
save(fullfile(root,"yolo_detector_trained_epoch5.mat"), "detector");

% Continue training with safe settings
options = trainingOptions("sgdm", ...
    InitialLearnRate=1e-4, ...
    MaxEpochs=15, ...                % this run adds ~15 more epochs
    MiniBatchSize=2, ...
    Shuffle="every-epoch", ...
    VerboseFrequency=20, ...
    ValidationData=dsVal, ...
    ValidationFrequency=100, ...
    GradientThreshold=1, ...
    Plots="training-progress", ...
    ExecutionEnvironment="cpu");

% Train more
[detector20, info20] = trainYOLOv4ObjectDetector(dsTrain, detector, options);

% Save the improved detector
save(fullfile(root,"yolo_detector_trained_epoch20.mat"), "detector20", "info20");
disp("Done. Saved: yolo_detector_trained_epoch20.mat");