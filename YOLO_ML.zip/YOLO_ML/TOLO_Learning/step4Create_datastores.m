%% STEP 4: Create datastores (dsTrain, dsVal) ready for YOLOv4 training
% This step does NOT train yet. It just prepares the data in the format
% trainYOLOv4ObjectDetector expects.

clear; clc;

root = "D:\Onedrive\OneDrive - IIT Delhi\IIT DElhi\Course\CAV COurse\Matlab\yoloLearn\archive\Cars Detection";
load(fullfile(root,"yolo_tables_carsDetection.mat"), "trainTbl", "valTbl", "classNames");

% Class columns (everything except imageFilename)
boxCols = trainTbl.Properties.VariableNames;
boxCols = boxCols(~strcmp(boxCols,"imageFilename"));

% 1) Image datastores
imdsTrain = imageDatastore(trainTbl.imageFilename);
imdsVal   = imageDatastore(valTbl.imageFilename);

% 2) Box label datastores
bldsTrain = boxLabelDatastore(trainTbl(:, boxCols));
bldsVal   = boxLabelDatastore(valTbl(:, boxCols));

% 3) Combined datastores (each read returns {image, boxData})
dsTrain = combine(imdsTrain, bldsTrain);
dsVal   = combine(imdsVal, bldsVal);

% 4) Quick check: read one sample
data = read(dsTrain);
I = data{1};
boxData = data{2};

disp("Read one training sample successfully.");
fprintf("Image size: %d x %d x %d\n", size(I,1), size(I,2), size(I,3));
disp("Box data preview (one row per class):");
disp(boxData);

% 5) Reset datastore (so training starts from beginning later)
reset(dsTrain);
reset(dsVal);

% Save prepared datastores if you want (optional)
save(fullfile(root,"yolo_datastores_carsDetection.mat"), "dsTrain", "dsVal", "classNames", "boxCols", "-v7.3");

disp("Step 4 complete: dsTrain and dsVal created and saved to yolo_datastores_carsDetection.mat");
