%% STEP 9B: Long training run (continue from epoch20) - CPU
clear; clc;

root = "D:\Onedrive\OneDrive - IIT Delhi\IIT DElhi\Course\CAV COurse\Matlab\yoloLearn\archive\Cars Detection";

% Load datastore (use CLEAN if you used it earlier; else normal)
if isfile(fullfile(root,"yolo_datastores_carsDetection_CLEAN.mat"))
    load(fullfile(root,"yolo_datastores_carsDetection_CLEAN.mat"), "dsTrain", "dsVal");
else
    load(fullfile(root,"yolo_datastores_carsDetection.mat"), "dsTrain", "dsVal");
end

% Load the latest good detector (epoch20)
load(fullfile(root,"yolo_detector_trained_epoch20.mat"), "detector20");
detector = detector20;

% Training options (stable for long CPU run)
options = trainingOptions("sgdm", ...
    InitialLearnRate=1e-4, ...
    MaxEpochs=30, ...              % long run (adds ~30 more passes)
    MiniBatchSize=2, ...
    Shuffle="every-epoch", ...
    VerboseFrequency=50, ...
    ValidationData=dsVal, ...
    ValidationFrequency=200, ...
    GradientThreshold=1, ...
    Plots="training-progress", ...
    ExecutionEnvironment="cpu");

% Train more
[detector50, info50] = trainYOLOv4ObjectDetector(dsTrain, detector, options);

% Save as new file (do not overwrite earlier ones)
save(fullfile(root,"yolo_detector_trained_epoch50.mat"), "detector50", "info50");
disp("Done. Saved: yolo_detector_trained_epoch50.mat");