%% CLEAN: Clamp boxes to image and remove invalid ones
clear; clc;

root = "D:\Onedrive\OneDrive - IIT Delhi\IIT DElhi\Course\CAV COurse\Matlab\yoloLearn\archive\Cars Detection";
load(fullfile(root,"yolo_tables_carsDetection.mat"), "trainTbl", "valTbl", "classNames");

trainTbl2 = cleanTableBoxes(trainTbl);
valTbl2   = cleanTableBoxes(valTbl);

save(fullfile(root,"yolo_tables_carsDetection_CLEAN.mat"), "trainTbl2", "valTbl2", "classNames");
disp("Saved cleaned tables: yolo_tables_carsDetection_CLEAN.mat");

function T2 = cleanTableBoxes(T)
    T2 = T;
    boxCols = T.Properties.VariableNames;
    boxCols = boxCols(~strcmp(boxCols,"imageFilename"));

    for i = 1:height(T2)
        imgPath = string(T2.imageFilename(i));
        info = imfinfo(imgPath);
        W = info.Width; H = info.Height;

        for k = 1:numel(boxCols)
            B = T2.(boxCols{k}){i};
            if isempty(B); continue; end

            % Clamp x,y to >=0
            x = max(0, B(:,1));
            y = max(0, B(:,2));
            w = B(:,3);
            h = B(:,4);

            % Clamp w,h so box stays in image
            w = min(w, W - x);
            h = min(h, H - y);

            % Remove invalid
            good = ~(any(isnan([x y w h]),2) | any(isinf([x y w h]),2) | (w <= 1) | (h <= 1));
            Bc = [x(good) y(good) w(good) h(good)];

            T2.(boxCols{k}){i} = Bc;
        end
    end
end
