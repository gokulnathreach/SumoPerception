%% STEP 7A (better): Show predictions with threshold=0.01 + top-K filtering
clear; clc; close all;

root = "D:\Onedrive\OneDrive - IIT Delhi\IIT DElhi\Course\CAV COurse\Matlab\yoloLearn\archive\Cars Detection";
load(fullfile(root,"yolo_detector_trained.mat"), "detector");
load(fullfile(root,"yolo_tables_carsDetection.mat"), "valTbl");

rng(0);
nShow = min(10, height(valTbl));
idx = randperm(height(valTbl), nShow);

threshold = 0.01;
topK = 5;   % show only top 5 predictions per image

for n = 1:nShow
    i = idx(n);
    imgPath = string(valTbl.imageFilename(i));
    I = imread(imgPath);

    [bboxes, scores, labels] = detect(detector, I, "Threshold", threshold);

    % Keep only topK highest scores (so the image is readable)
    if ~isempty(scores)
        [scores, order] = sort(scores, "descend");
        order = order(1:min(topK, numel(order)));
        bboxes = bboxes(order,:);
        scores = scores(1:numel(order));
        labels = labels(order);
    end

    if ~isempty(bboxes)
        ann = string(labels) + " : " + string(round(scores,3));
        I2 = insertObjectAnnotation(I, "rectangle", bboxes, ann);
    else
        I2 = I;
    end

    figure(1); imshow(I2);
    title(sprintf("Top-%d predictions (Thr=%.3f) | %s", topK, threshold, imgPath), "Interpreter","none");
    disp("Press Enter for next image...");
    pause;
end