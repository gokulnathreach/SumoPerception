%% STEP 5 (fixed): Estimate anchors from dsTrain and create YOLOv4 detector
clear; clc;

root = "D:\Onedrive\OneDrive - IIT Delhi\IIT DElhi\Course\CAV COurse\Matlab\yoloLearn\archive\Cars Detection";

% Load from Step 4 and Step 2
load(fullfile(root,"yolo_datastores_carsDetection.mat"), "dsTrain", "dsVal", "boxCols"); %#ok<NASGU>
load(fullfile(root,"yolo_tables_carsDetection.mat"), "classNames");

% For YOLOv4 full model: 3 detection heads => 9 anchors total
numAnchors = 9;

% estimateAnchorBoxes needs a datastore in your MATLAB
[anchors, meanIoU] = estimateAnchorBoxes(dsTrain, numAnchors);

fprintf("Estimated anchors (w,h) in pixels:\n");
disp(anchors);
fprintf("Mean IoU with estimated anchors: %.3f\n", meanIoU);

% Sort anchors by area (largest first)
area = anchors(:,1).*anchors(:,2);
[~, idx] = sort(area, "descend");
anchors = anchors(idx,:);

% Split into 3 groups (3 anchors per detection head)
anchorBoxes = {anchors(1:3,:); anchors(4:6,:); anchors(7:9,:)};

inputSize = [416 416 3];

% Create YOLOv4 detector (your MATLAB requires anchorBoxes as 3-cell)
detector = yolov4ObjectDetector("csp-darknet53-coco", classNames, anchorBoxes, InputSize=inputSize);

disp("Detector created. Classes:");
disp(detector.ClassNames);

save(fullfile(root,"yolo_detector_init.mat"), "detector", "anchorBoxes", "anchors", "inputSize", "classNames", "meanIoU");

