%% STEP 1: Verify YOLO dataset structure (Cars Detection)
clear; clc;

root = "D:\Onedrive\OneDrive - IIT Delhi\IIT DElhi\Course\CAV COurse\Matlab\yoloLearn\archive\Cars Detection";

splits = ["train","valid","test"];

fprintf("Dataset root: %s\n\n", root);

for s = 1:numel(splits)
    split = splits(s);

    imgDir = fullfile(root, split, "images");
    labDir = fullfile(root, split, "labels");

    fprintf("---- %s ----\n", upper(split));
    fprintf("images folder exists: %d | %s\n", isfolder(imgDir), imgDir);
    fprintf("labels folder exists: %d | %s\n", isfolder(labDir), labDir);

    % Count images
    jpg  = dir(fullfile(imgDir,"*.jpg"));
    jpeg = dir(fullfile(imgDir,"*.jpeg"));
    png  = dir(fullfile(imgDir,"*.png"));
    nImgs = numel(jpg)+numel(jpeg)+numel(png);

    % Count label files
    txt = dir(fullfile(labDir,"*.txt"));
    nLbl = numel(txt);

    fprintf("Images: %d | Label TXT files: %d\n", nImgs, nLbl);

    % Show one example label line
    if nLbl > 0
        exampleLab = fullfile(txt(1).folder, txt(1).name);
        fprintf("Example label file: %s\n", txt(1).name);

        fid = fopen(exampleLab,'r');
        if fid>0
            line1 = fgetl(fid);
            fclose(fid);
            fprintf("First label line: %s\n", string(line1));
            fprintf("Format should be: class x_center y_center w h (normalized)\n");
        end
    end

    % Check how many images have matching label files (by base name)
    imgFiles = [jpg; jpeg; png];
    imgBases = strings(numel(imgFiles),1);
    for i = 1:numel(imgFiles)
        [~,b,~] = fileparts(imgFiles(i).name);
        imgBases(i) = b;
    end

    lblBases = strings(nLbl,1);
    for i = 1:nLbl
        [~,b,~] = fileparts(txt(i).name);
        lblBases(i) = b;
    end

    nMatch = sum(ismember(imgBases, lblBases));
    fprintf("Images with a matching label TXT (same base name): %d / %d\n\n", nMatch, nImgs);
end
