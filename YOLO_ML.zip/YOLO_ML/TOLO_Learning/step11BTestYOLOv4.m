%% STEP 11B: Test on TEST split (Ground Truth vs Prediction) if labels exist
clear; clc; close all;

root = "D:\Onedrive\OneDrive - IIT Delhi\IIT DElhi\Course\CAV COurse\Matlab\yoloLearn\archive\Cars Detection";
load(fullfile(root,"yolo_detector_trained_epoch50.mat"), "detector50");
detector = detector50;

% Load class names (used to decode YOLO class ids)
load(fullfile(root,"yolo_tables_carsDetection.mat"), "classNames");

testImgDir = fullfile(root, "test", "images");
testLabDir = fullfile(root, "test", "labels");

imdsTest = imageDatastore(testImgDir);

threshold = 0.10;
topK = 8;
nShow = min(15, numel(imdsTest.Files));

rng(1);
idx = randperm(numel(imdsTest.Files), nShow);

for n = 1:nShow
    imgPath = string(imdsTest.Files{idx(n)});
    I = imread(imgPath);

    % ---------- GT from YOLO txt ----------
    [~, base, ~] = fileparts(imgPath);
    labPath = fullfile(testLabDir, base + ".txt");

    gtBoxes = [];
    gtLabels = strings(0);

    if isfile(labPath)
        info = imfinfo(imgPath);
        W = info.Width; H = info.Height;

        lines = readlines(labPath);
        lines = strtrim(lines);
        lines(lines=="") = [];

        for j = 1:numel(lines)
            parts = split(lines(j));
            cls = str2double(parts(1));
            xc  = str2double(parts(2));
            yc  = str2double(parts(3));
            bw  = str2double(parts(4));
            bh  = str2double(parts(5));

            boxW = bw * W;
            boxH = bh * H;
            x = (xc * W) - boxW/2;
            y = (yc * H) - boxH/2;

            gtBoxes  = [gtBoxes; [x y boxW boxH]]; %#ok<AGROW>
            gtLabels = [gtLabels; string(classNames(cls+1))]; %#ok<AGROW>
        end
    end

    Igt = I;
    if ~isempty(gtBoxes)
        Igt = insertObjectAnnotation(Igt, "rectangle", gtBoxes, gtLabels);
    end

    % ---------- Predictions ----------
    [bboxes, scores, labels] = detect(detector, I, "Threshold", threshold);

    if ~isempty(scores)
        [scores, order] = sort(scores, "descend");
        order = order(1:min(topK, numel(order)));
        bboxes = bboxes(order,:);
        scores = scores(1:numel(order));
        labels = labels(order);

        ann = string(labels) + " : " + string(round(scores,2));
        Ipred = insertObjectAnnotation(I, "rectangle", bboxes, ann);
    else
        Ipred = I;
    end

    % ---------- Display ----------
    figure(1); clf;
    tiledlayout(1,2,"Padding","compact","TileSpacing","compact");
    nexttile; imshow(Igt);   title("TEST Ground Truth");
    nexttile; imshow(Ipred); title(sprintf("TEST Prediction (Thr=%.2f)", threshold));

    sgtitle(sprintf("Image %d/%d | %s", n, numel(idx), imgPath), "Interpreter","none");

    disp("Press Enter...");
    pause;
end