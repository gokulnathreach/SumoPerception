img = imread("highway.png");
detector = yolov4ObjectDetector("csp-darknet53-coco");
[bboxes, scores, labels] = detect(detector, img, 'Threshold', 0.3);

% --- 1) Use REAL intrinsics from calibration (recommended)
% intrinsics = cameraIntrinsics(focalLength, principalPoint, imageSize);
% Example placeholders:
focalLength    = [1100 1100];   % [fx fy] in pixels
principalPoint = [size(img,2)/2 size(img,1)/2];
imageSize      = [size(img,1) size(img,2)];
intrinsics = cameraIntrinsics(focalLength, principalPoint, imageSize);

% --- 2) Mounting parameters (measure/assume)
cameraHeight = 1.5;          % meters (typical car dashcam)
pitchDeg     = 2;            % degrees downward pitch (estimate)
sensor = monoCamera(intrinsics, cameraHeight, 'Pitch', pitchDeg);

figure; imshow(img); title("Detections + ground-plane distance");
imgOut = img;

for i = 1:size(bboxes,1)
    bb = bboxes(i,:);

    % bottom-center pixel of bbox (likely touches the road for vehicles)
    u = bb(1) + bb(3)/2;
    v = bb(2) + bb(4);
    imagePoint = [u v];

    % Project to vehicle coordinates on ground plane
    vehiclePoint = imageToVehicle(sensor, imagePoint); % [X Y] in meters

    X = vehiclePoint(1); % forward distance (m)
    Y = vehiclePoint(2); % lateral (m)
    dist = hypot(X, Y);

    txt = sprintf("%s: %.2f (%.1f m)", string(labels(i)), scores(i), dist);
    imgOut = insertObjectAnnotation(imgOut, "rectangle", bb, txt);
end

imshow(imgOut);
