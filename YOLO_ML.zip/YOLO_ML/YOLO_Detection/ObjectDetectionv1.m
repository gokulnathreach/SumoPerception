img = imread("highway.png");

% img = imread("highway.png");
detector = yolov4ObjectDetector("csp-darknet53-coco"); % if available in your install
[bboxes, scores, labels] = detect(detector, img, 'Threshold', 0.3);

figure; imshow(img); title("Final detections (after post-processing)");
if ~isempty(bboxes)
    annotation = string(labels) + " : " + string(round(scores,2));
    imgOut = insertObjectAnnotation(img, "rectangle", bboxes, annotation);
    imshow(imgOut);
end