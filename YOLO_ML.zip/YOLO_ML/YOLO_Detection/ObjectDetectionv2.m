img = imread("highway.png");

detector = yolov4ObjectDetector("csp-darknet53-coco");
[bboxes, scores, labels] = detect(detector, img, 'Threshold', 0.3);

% --- You need camera intrinsics (best: from calibration)
% Example placeholders (REPLACE with real calibration):
fy = 1100;  % focal length in pixels (example!)

% Assumed typical object heights (meters)
Hcar   = 1.5;
Htruck = 3.0;
Hbus   = 3.2;
Hperson = 1.7;

figure; imshow(img); title("Detections + approximate distance");

if ~isempty(bboxes)
    imgOut = img;

    for i = 1:size(bboxes,1)
        h = bboxes(i,4); % bbox height in pixels

        % pick assumed real height by class
        cls = string(labels(i));
        if cls == "car"
            H = Hcar;
        elseif cls == "truck"
            H = Htruck;
        elseif cls == "bus"
            H = Hbus;
        elseif cls == "person"
            H = Hperson;
        else
            H = NaN; % unknown -> skip distance
        end

        if ~isnan(H) && h > 0
            Z = (fy * H) / h; % meters (approx)
            txt = sprintf("%s: %.2f (%.1f m)", cls, scores(i), Z);
        else
            txt = sprintf("%s: %.2f", cls, scores(i));
        end

        imgOut = insertObjectAnnotation(imgOut, "rectangle", bboxes(i,:), txt);
    end

    imshow(imgOut);
end
